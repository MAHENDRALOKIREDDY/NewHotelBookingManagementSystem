package com.cg.hbm.exceptions;


@SuppressWarnings("serial")
public class RoomDetailsNotFoundException extends Exception {
	
	public RoomDetailsNotFoundException(String message) {
		super(message);
	}
	}


